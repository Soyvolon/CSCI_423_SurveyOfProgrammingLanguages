#include "University.h"

University::University(std::string name)
{
	this->name = name;
}

int University::getStudentCount()
{
	return this->studentCount;
}

int University::getStaffCount()
{
	return this->staffCount;
}

std::string University::getName()
{
	return this->name;
}

void University::setStudentCount(int students)
{
	this->studentCount = students;
}

void University::setStaffCount(int staff)
{
	this->staffCount = staff;
}

void University::setName(std::string name)
{
	this->name = name;
}