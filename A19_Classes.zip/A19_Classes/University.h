#pragma once
#include <string>

class University
{
private:
	int studentCount;
	int staffCount;
	std::string name;

public:
	University(std::string name);

	int getStudentCount();
	int getStaffCount();
	std::string getName();

	void setStudentCount(int students);
	void setStaffCount(int staff);
	void setName(std::string name);
};

